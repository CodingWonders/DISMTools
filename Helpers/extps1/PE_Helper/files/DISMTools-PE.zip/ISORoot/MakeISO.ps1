#requires -version 5.0
#                                              ....              
#                                         .'^""""""^.            
#      '^`'.                            '^"""""""^.              
#     .^"""""`'                       .^"""""""^.                ---------------------------------------------------------
#      .^""""""`                      ^"""""""`                  | DISMTools                                             |
#       ."""""""^.                   `""""""""'           `,`    | The connected place for Windows system administration |
#         '`""""""`.                 """""""""^         `,,,"    ---------------------------------------------------------
#            '^"""""`.               ^""""""""""'.   .`,,,,,^    | Preinstallation Environment (PE) helper               |
#              .^"""""`.            ."""""""",,,,,,,,,,,,,,,.    ---------------------------------------------------------
#                .^"""""^.        .`",,"""",,,,,,,,,,,,,,,,'     | (C) 2024 CodingWonders Software                       |
#                  .^"""""^.    '`^^"",:,,,,,,,,,,,,,,,,,".      ---------------------------------------------------------
#                    .^"""""^.`+]>,^^"",,:,,,,,,,,,,,,,`.        
#                      .^""";_]]]?)}:^^""",,,`'````'..           
#                        .;-]]]?(xxxx}:^^^^'                     
#                       `+]]]?(xxxxxxxr},'                       
#                     .`:+]?)xxxxxxxxxxxr<.                      
#                   .`^^^^:(xxxxxxxxxxxxxxr>.                    
#                 .`^^^^^^^^I(xxxxxxxxxxxxxxr<.                  
#               .`^^^^^^^^^^^^I(xxxxxxxxxxxxxxr<.                
#             .`^^^^^^^^^^^^^^^'`[xxxxxxxxxxxxxxr<.              
#           .`^^^^^^^^^^^^^^^'    `}xxxxxxxxxxxxxxr<.            
#          `^^":ll:"^^^^^^^'        `}xxxxxxxxxxxxxxr,           
#         '^^^I-??]l^^^^^'            `[xxxxxxxxxxxxxx.          This script is provided AS IS, without any warranty. It shouldn't
#         '^^^,<??~,^^^'                `{xxxxxxxxxxxx.          do any damage to your computer, but you still need to be careful over
#          `^^^^^^^^^'                    `{xxxxxxxxr,           what you do with it.

using namespace System.Collections.Generic;

try
{
	if (Test-Path ".\winpe.iso" -PathType Leaf)
	{
		# Check if the ISO file exists
		Remove-Item -Path ".\winpe.iso" -Force
	}
	# Check if Apps folder is present and add apps to Tools folder
	if (Test-Path "..\Apps")
	{
		Write-Host "Copying your applications..."
		New-Item -Path "$((Get-Location).Path)\media\Tools\Apps" -ItemType Directory -Force | Out-Null
		Copy-Item "..\Apps\*" "$((Get-Location).Path)\media\Tools\Apps" -Recurse -Force -Verbose
	}
	# Detect whether files are in fwfiles or bootbins - ADK 10.1.26100.2454 and later put boot files in bootbins,
	# not in fwfiles. All of this to add support for the boot binaries signed with this certificate - I'm starting to
	# hate Microsoft's approach to security
	$paths = [List[string]]::new()
	$paths.Add("bootbins")
	$paths.Add("fwfiles")
	$finalPath = ""
	foreach ($path in $paths)
	{
		if (Test-Path "$((Get-Location).Path)\$path")
		{
			$finalPath = $path
			break
		}
	}
	if (Test-Path "$((Get-Location).Path)\$finalPath\etfsboot.com" -PathType Leaf)
	{
		Write-Host "Generating ISO file with BIOS and UEFI compatibility..."
		$bootData = "2#p0,e,b`"$((Get-Location).Path)\$finalPath\etfsboot.com`"#pEF,e,b`"$((Get-Location).Path)\$finalPath\efisys.bin`""
	}
	else
	{
		Write-Host "Generating ISO file with UEFI compatibility..."
		$bootData = "1#pEF,e,b`"$((Get-Location).Path)\$finalPath\efisys.bin`""
	}
	$oscdimgProc = Start-Process ".\oscdimg.exe" -ArgumentList "-bootdata:$bootData -u2 -udfver102 `"$((Get-Location).Path)\media`" `".\winpe.iso`"" -Wait -PassThru -NoNewWindow
	if ($oscdimgProc.ExitCode -eq 0)
	{
		Write-Host "The ISO file has been generated."            
	}
	else
	{
		Write-Host "The ISO file could not be generated." 
	}
}
catch
{
	Write-Host "The ISO file could not be generated."
	Start-Sleep -Seconds 2
}