#requires -version 5.0
#                                              ....              
#                                         .'^""""""^.            
#      '^`'.                            '^"""""""^.              
#     .^"""""`'                       .^"""""""^.                ---------------------------------------------------------
#      .^""""""`                      ^"""""""`                  | DISMTools                                             |
#       ."""""""^.                   `""""""""'           `,`    | The connected place for Windows system administration |
#         '`""""""`.                 """""""""^         `,,,"    ---------------------------------------------------------
#            '^"""""`.               ^""""""""""'.   .`,,,,,^    | Preinstallation Environment (PE) helper               |
#              .^"""""`.            ."""""""",,,,,,,,,,,,,,,.    ---------------------------------------------------------
#                .^"""""^.        .`",,"""",,,,,,,,,,,,,,,,'     | (C) 2024 CodingWonders Software                       |
#                  .^"""""^.    '`^^"",:,,,,,,,,,,,,,,,,,".      ---------------------------------------------------------
#                    .^"""""^.`+]>,^^"",,:,,,,,,,,,,,,,`.        
#                      .^""";_]]]?)}:^^""",,,`'````'..           
#                        .;-]]]?(xxxx}:^^^^'                     
#                       `+]]]?(xxxxxxxr},'                       
#                     .`:+]?)xxxxxxxxxxxr<.                      
#                   .`^^^^:(xxxxxxxxxxxxxxr>.                    
#                 .`^^^^^^^^I(xxxxxxxxxxxxxxr<.                  
#               .`^^^^^^^^^^^^I(xxxxxxxxxxxxxxr<.                
#             .`^^^^^^^^^^^^^^^'`[xxxxxxxxxxxxxxr<.              
#           .`^^^^^^^^^^^^^^^'    `}xxxxxxxxxxxxxxr<.            
#          `^^":ll:"^^^^^^^'        `}xxxxxxxxxxxxxxr,           
#         '^^^I-??]l^^^^^'            `[xxxxxxxxxxxxxx.          This script is provided AS IS, without any warranty. It shouldn't
#         '^^^,<??~,^^^'                `{xxxxxxxxxxxx.          do any damage to your computer, but you still need to be careful over
#          `^^^^^^^^^'                    `{xxxxxxxxr,           what you do with it.

try
{
	if (Test-Path ".\winpe.iso" -PathType Leaf)
	{
		# Check if the ISO file exists
		Remove-Item -Path ".\winpe.iso" -Force
	}
	# Check if Apps folder is present and add apps to Tools folder
	if (Test-Path "..\Apps")
	{
		Write-Host "Copying your applications..."
		New-Item -Path "$((Get-Location).Path)\media\Tools\Apps" -ItemType Directory -Force | Out-Null
		Copy-Item "..\Apps\*" "$((Get-Location).Path)\media\Tools\Apps" -Recurse -Force -Verbose
	}
	if (Test-Path "$((Get-Location).Path)\fwfiles\etfsboot.com" -PathType Leaf)
	{
		Write-Host "Generating ISO file with BIOS and UEFI compatibility..."
		$bootData = "2#p0,e,b`"$((Get-Location).Path)\fwfiles\etfsboot.com`"#pEF,e,b`"$((Get-Location).Path)\fwfiles\efisys.bin`""
	}
	else
	{
		Write-Host "Generating ISO file with UEFI compatibility..."
		$bootData = "1#pEF,e,b`"$((Get-Location).Path)\fwfiles\efisys.bin`""
	}
	Start-Process ".\oscdimg.exe" -ArgumentList "-bootdata:$bootData -u2 -udfver102 `"$((Get-Location).Path)\media`" `".\winpe.iso`"" -Wait | Out-Null
	if ($?)
	{
		Write-Host "The ISO file has been generated."            
	}
	else
	{
		Write-Host "The ISO file could not be generated." 
	}
	return $?
}
catch
{
	Write-Host "The ISO file could not be generated."
	return $false
}